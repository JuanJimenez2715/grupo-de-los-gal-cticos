<?php
/* Template Name: Contacto */
get_header(); ?>

<div class="container">
    <h1>Contacto</h1>
    <p>Para cualquier consulta, por favor completa el siguiente formulario de contacto:</p>
    <div class="contact-form">
        <?php echo do_shortcode('[contact-form-7 id="123" title="Formulario de Contacto"]'); // Ajusta el ID según el formulario creado ?>
    </div>
</div>

<?php get_footer(); ?>
