<?php get_header(); ?>

<div class="container">
    <!-- Título y descripción del sitio -->
    <h1><?php bloginfo('name'); ?></h1>
    <p><?php bloginfo('description'); ?></p>

    <!-- Sección de Noticias -->
    <section id="noticias">
        <h2>Noticias Universitarias</h2>
        <?php
        $noticias_query = new WP_Query(array(
            'category_name' => 'noticias', // Asegúrate de tener una categoría llamada "noticias"
            'posts_per_page' => 3 // Muestra las últimas 3 noticias
        ));
        if ($noticias_query->have_posts()) :
            while ($noticias_query->have_posts()) : $noticias_query->the_post();
        ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="post-meta">
                        <span><?php the_date(); ?></span>
                    </div>
                    <div class="post-excerpt">
                        <?php the_excerpt(); ?>
                    </div>
                </article>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
            echo '<p>No hay noticias recientes.</p>';
        endif;
        ?>
    </section>

    <!-- Sección de Eventos -->
    <section id="eventos">
        <h2>Próximos Eventos</h2>
        <?php
        // Si usas The Events Calendar, puedes usar su shortcode o función aquí:
        echo do_shortcode('[events_calendar]'); // Usa el shortcode adecuado según el plugin instalado.
        ?>
    </section>

    <!-- Sección de Servicios Universitarios -->
    <section id="servicios">
        <h2>Servicios Universitarios</h2>
        <?php
        $servicios_query = new WP_Query(array(
            'post_type' => 'servicios', // Asegúrate de registrar este tipo de publicación personalizado
            'posts_per_page' => 3
        ));
        if ($servicios_query->have_posts()) :
            while ($servicios_query->have_posts()) : $servicios_query->the_post();
        ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="post-excerpt">
                        <?php the_excerpt(); ?>
                    </div>
                </article>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
            echo '<p>No hay servicios disponibles.</p>';
        endif;
        ?>
    </section>

    <!-- Sección de Blog -->
    <section id="blog">
        <h2>Blog Universitario</h2>
        <?php
        $blog_query = new WP_Query(array(
            'category_name' => 'blog', // Usa una categoría llamada "blog"
            'posts_per_page' => 3
        ));
        if ($blog_query->have_posts()) :
            while ($blog_query->have_posts()) : $blog_query->the_post();
        ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="post-meta">
                        <span><?php the_date(); ?></span>
                    </div>
                    <div class="post-excerpt">
                        <?php the_excerpt(); ?>
                    </div>
                </article>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
            echo '<p>No hay publicaciones de blog.</p>';
        endif;
        ?>
    </section>

    <!-- Sección de Documentos -->
    <section id="documentos">
        <h2>Documentos Importantes</h2>
        <?php
        $documentos_query = new WP_Query(array(
            'post_type' => 'documentos', // Asegúrate de registrar este tipo de publicación personalizado
            'posts_per_page' => 3
        ));
        if ($documentos_query->have_posts()) :
            while ($documentos_query->have_posts()) : $documentos_query->the_post();
        ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <div class="post-content">
                        <?php the_content(); ?>
                    </div>
                </article>
        <?php
            endwhile;
            wp_reset_postdata();
        else :
            echo '<p>No hay documentos disponibles.</p>';
        endif;
        ?>
    </section>

    <!-- Sección de Contacto -->
    <section id="contacto">
        <h2>Contacto</h2>
        <p>Para cualquier consulta, por favor completa el formulario de contacto.</p>
        <?php echo do_shortcode('[contact-form-7 id="123" title="Formulario de Contacto"]'); ?>
    </section>
</div>

<?php get_footer(); ?>
