<?php
/*
Template Name: Página de Blog
*/

get_header(); ?>

<div class="container">
    <h1>Blog</h1>
    <div class="blog-posts">
        <?php
        // Argumentos para mostrar solo las entradas de la categoría "blog"
        $args = array(
            'category_name' => 'blog', // Asegúrate de que el slug sea "blog"
            'post_type' => 'post',
            'posts_per_page' => 10 // Ajusta la cantidad de publicaciones por página
        );

        // Consulta personalizada de entradas
        $blog_query = new WP_Query($args);

        if ($blog_query->have_posts()) :
            while ($blog_query->have_posts()) : $blog_query->the_post(); ?>
                <article class="post">
                    <div class="post-thumbnail">
                        <?php if (has_post_thumbnail()) : ?>
                            <a href="<?php the_permalink(); ?>">
                                <?php the_post_thumbnail('medium'); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="post-content">
                        <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                        <p class="post-meta">Publicado el <?php the_time('F j, Y'); ?> por <?php the_author(); ?></p>
                        <p><?php the_excerpt(); ?></p>
                        <a href="<?php the_permalink(); ?>" class="read-more">Leer más</a>
                    </div>
                </article>
            <?php endwhile;
            wp_reset_postdata();
        else : ?>
            <p>No se han encontrado entradas en el blog.</p>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
