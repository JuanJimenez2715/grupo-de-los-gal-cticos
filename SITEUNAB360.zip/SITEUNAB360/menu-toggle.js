    document.addEventListener('DOMContentLoaded', function () {
        const toggleButton = document.getElementById('mobile-menu-toggle');
        const mainMenu = document.getElementById('main-menu');

        toggleButton.addEventListener('click', function () {
            mainMenu.classList.toggle('active');
        });
    });