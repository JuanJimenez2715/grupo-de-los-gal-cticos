<?php
/* Template Name: Página de Noticias */
get_header(); ?>

<div class="container">
    <h1>Noticias</h1>

    <?php
    $noticias_query = new WP_Query(array(
        'category_name' => 'servicios', // Slug de la categoría
        'posts_per_page' => 10, // Número de noticias por página
    ));

    if ($noticias_query->have_posts()) :
        while ($noticias_query->have_posts()) : $noticias_query->the_post(); ?>
            <article>
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <div class="post-meta"><?php the_time('F j, Y'); ?></div>
                <div class="post-excerpt"><?php the_excerpt(); ?></div>
            </article>
        <?php endwhile;
        wp_reset_postdata();
    else : ?>
        <p>No hay Servicios disponibles.</p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
