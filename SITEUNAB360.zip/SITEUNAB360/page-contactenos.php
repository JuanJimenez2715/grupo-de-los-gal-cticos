<?php
/* Template Name: Página de Noticias */
get_header(); ?>

<div class="contact-page-container">
    <!-- Información de Contacto -->
    <div class="contact-info">
        <h2>Contáctenos</h2>
        <p>Si tienes preguntas, sugerencias o necesitas información adicional, no dudes en contactarnos.</p>
        <div class="contact-details">
            <p><i class="fas fa-phone-alt"></i> Teléfono: 018000127395</p>
            <p><i class="fas fa-envelope"></i> Email: contactenos@unab.edu.co</p>
            <p><i class="fas fa-map-marker-alt"></i> Av. 42 #48 - 11, Bucaramanga, Santander</p>
        </div>
        <div class="social-icons">
            <a href="https://facebook.com/unab" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a href="https://twitter.com/unab" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com/unab" target="_blank"><i class="fab fa-instagram"></i></a>
        </div>
    </div>

    <!-- Formulario de Contacto -->
    <div class="contact-form">
        <h3>Envíanos un mensaje</h3>
        <form action="/enviar-contacto" method="POST">
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" required>
            <label for="email">Correo Electrónico:</label>
            <input type="email" id="email" name="email" required>
            <label for="mensaje">Mensaje:</label>
            <textarea id="mensaje" name="mensaje" rows="4" required></textarea>
            <button type="submit">Enviar</button>
        </form>
    </div>

    <!-- Mapa de Google -->
    <div class="map-container">
        <h3>Ubicación</h3>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3959.078639283976!2d-73.10778122431796!3d7.116885515982048!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e683fe3d972e479%3A0xf4d24fabc68b8c!2sUniversidad%20Aut%C3%B3noma%20de%20Bucaramanga%20-%20UNAB!5e0!3m2!1ses-419!2sco!4v1730074391359!5m2!1ses-419!2sco" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
</div>


<?php get_footer(); ?>
