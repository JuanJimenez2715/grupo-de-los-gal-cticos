<?php get_header(); ?>

<div class="container">
    <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            <h1><?php the_title(); ?></h1>
            <div class="post-meta">
                <span>Publicado el: <?php the_date(); ?></span> | 
                <span>Autor: <?php the_author(); ?></span>
            </div>
            <div class="post-content">
                <?php the_content(); ?>
            </div>
        </article>
        <!-- Sección de Comentarios -->
        <?php
        // Solo mostrar comentarios si están habilitados o hay al menos uno
        if (comments_open() || get_comments_number()) :
            comments_template();
        endif;
        ?>
    <?php endwhile; else : ?>
        <p>No se encontró el contenido.</p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
