<?php
//Registrar usuarios
//function inicializar_datos_usuario($user_id) {
    // Verifica si el rol del usuario es 'estudiante'
//    $user = get_userdata($user_id);
//    if (in_array('estudiante', $user->roles)) {
//        // Inicializa los metadatos
//        update_user_meta($user_id, 'horas_realizadas', 0);
//        update_user_meta($user_id, 'actividades_realizadas', array());
//    }
//}
//add_action('user_register', 'inicializar_datos_usuario');
function registrar_rol_estudiante() {
    add_role(
        'estudiante',
        'Estudiante',
        array(
            'read' => true, // Permiso básico para leer contenido
        )
    );
}
add_action('init', 'registrar_rol_estudiante');

function inicializar_datos_usuario($user_id) {
    // Verifica si el usuario tiene el rol 'estudiante'
    $user = get_userdata($user_id);
    if (in_array('estudiante', $user->roles)) {
        if (!get_user_meta($user_id, 'horas_totales_asignadas', true)) {
            update_user_meta($user_id, 'horas_totales_asignadas', 100); // Valor por defecto
        }
        if (!get_user_meta($user_id, 'horas_realizadas', true)) {
            update_user_meta($user_id, 'horas_realizadas', 0);
        }
        if (!get_user_meta($user_id, 'actividades_realizadas', true)) {
            update_user_meta($user_id, 'actividades_realizadas', array());
        }
        if (!get_user_meta($user_id, 'actividades_completadas', true)) {
            update_user_meta($user_id, 'actividades_completadas', array());
        }
    }
}
add_action('user_register', 'inicializar_datos_usuario');

function inicializar_datos_estudiante($user_id) {
    $horas_totales_asignadas = get_user_meta($user_id, 'horas_totales_asignadas', true);
    if (!$horas_totales_asignadas) {
        update_user_meta($user_id, 'horas_totales_asignadas', 100); // Valor por defecto
    }

    $actividades_completadas = get_user_meta($user_id, 'actividades_completadas', true);
    if (!$actividades_completadas) {
        update_user_meta($user_id, 'actividades_completadas', []);
    }
}
add_action('user_register', 'inicializar_datos_estudiante');

function registrar_tipo_contenido_actividad() {
    $args = array(
        'labels' => array(
            'name' => 'Actividades',
            'singular_name' => 'Actividad',
        ),
        'public' => true,
        'has_archive' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'rewrite' => array('slug' => 'actividad'),
    );
    register_post_type('actividad', $args);
}
add_action('init', 'registrar_tipo_contenido_actividad');

function agregar_permisos_rol_estudiante() {
    $role = get_role('estudiante');
    if ($role) {
        $role->add_cap('read');
    }
}
add_action('init', 'agregar_permisos_rol_estudiante');

// Registrar menús de navegación
function universidad_menus() {
    register_nav_menus(array(
        'primary' => __('Menú Principal'),
        'footer' => __('Menú del Pie de Página')
    ));
}
add_action('init', 'universidad_menus');

// Registrar Custom Post Types para Servicios y Documentos
function universidad_custom_post_types() {
    // Servicios Universitarios
    register_post_type('servicios', array(
        'public' => true,
        'label' => 'Servicios Universitarios',
        'supports' => array('title', 'editor', 'thumbnail')
    ));
    
    // Documentos Importantes
    register_post_type('documentos', array(
        'public' => true,
        'label' => 'Documentos',
        'supports' => array('title', 'editor', 'thumbnail')
    ));
}
add_action('init', 'universidad_custom_post_types');

// Encolar estilos y scripts
function universidad_enqueue_styles() {
    wp_enqueue_style('main-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'universidad_enqueue_styles');

// Registrar menús personalizados (si no está registrado anteriormente)
function universidad_register_menus() {
    register_nav_menus(array(
        'top-menu' => __('Menú Superior Universitario', 'universidad-tema'),
        'main-menu' => __('Menú Principal', 'universidad-tema'),
    ));
}

// Asegurarse de que la función solo se ejecute una vez
if (!has_action('init', 'universidad_register_menus')) {
    add_action('init', 'universidad_register_menus');
}

// // Habilitar imágenes destacadas
if (function_exists('add_theme_support')) {
    add_theme_support('post-thumbnails');
}
function agregar_menu_toggle_script() {
    wp_enqueue_script('menu-toggle', get_template_directory_uri() . '/menu-toggle.js', array(), null, true);
}
add_theme_support('post-thumbnails');
set_post_thumbnail_size(150, 150, true);
add_action('wp_enqueue_scripts', 'agregar_menu_toggle_script');

function cargar_font_awesome() {
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');
}
add_action('wp_enqueue_scripts', 'cargar_font_awesome');

/*
function cargar_font_awesome() {
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css', array(), '6.0.0-beta3');
}
add_action('wp_enqueue_scripts', 'cargar_font_awesome');
*/

// Añadir campo personalizado en el formulario de edición de la categoría
function agregar_campo_personalizado_categoria($tag) {
    // Obtener el valor actual del campo personalizado
    $custom_field_value = get_term_meta($tag->term_id, 'tipo_documento', true);
    ?>
    <tr class="form-field">
        <th scope="row" valign="top">
            <label for="tipo_documento">Tipo de Documento</label>
        </th>
        <td>
            <input type="text" name="tipo_documento" id="tipo_documento" value="<?php echo esc_attr($custom_field_value); ?>" />
            <p class="description">Descripción del campo personalizado.</p>
        </td>
    </tr>
    <?php
}
add_action('category_edit_form_fields', 'agregar_campo_personalizado_categoria');

// Guardar el campo personalizado
function guardar_campo_personalizado_categoria($term_id) {
    if (isset($_POST['tipo_documento'])) {
        update_term_meta($term_id, 'tipo_documento', sanitize_text_field($_POST['tipo_documento']));
    }
}
add_action('edited_category', 'guardar_campo_personalizado_categoria');
// Fin agregar campo a entrada documentos

function mostrar_documento_con_icono($nombre, $ruta) {
    $extension = pathinfo($ruta, PATHINFO_EXTENSION);

    switch ($extension) {
        case 'pdf':
            $icono = 'fas fa-file-pdf';
            break;
        case 'doc':
        case 'docx':
            $icono = 'fas fa-file-word';
            break;
        case 'xls':
        case 'xlsx':
            $icono = 'fas fa-file-excel';
            break;
        case 'ppt':
        case 'pptx':
            $icono = 'fas fa-file-powerpoint';
            break;
        default:
            $icono = 'fas fa-file';
    }

    echo '<div class="document-item">';
    echo '<i class="' . $icono . '"></i> <a href="' . esc_url($ruta) . '" target="_blank">' . esc_html($nombre) . '</a>';
    echo '</div>';
}

function agregar_icono_tipo_documento($content) {
    // Busca patrones de enlaces de archivos en el contenido de la entrada
    $pattern = '/<a href="([^"]+\.(pdf|docx?|xlsx?|pptx?))"[^>]*>(.*?)<\/a>/i';
    $content = preg_replace_callback($pattern, function($matches) {
        $url = $matches[1];
        $extension = $matches[2];
        $nombre = $matches[3];

        // Selecciona el ícono en función del tipo de archivo
        switch (strtolower($extension)) {
            case 'pdf':
                $icono = 'fas fa-file-pdf';
                break;
            case 'doc':
            case 'docx':
                $icono = 'fas fa-file-word';
                break;
            case 'xls':
            case 'xlsx':
                $icono = 'fas fa-file-excel';
                break;
            case 'ppt':
            case 'pptx':
                $icono = 'fas fa-file-powerpoint';
                break;
            default:
                $icono = 'fas fa-file';
        }

        // Retorna el enlace modificado con el ícono
        return '<i class="' . $icono . '"></i> <a href="' . esc_url($url) . '" target="_blank">' . esc_html($nombre) . '</a>';
    }, $content);

    return $content;
}
add_filter('the_content', 'agregar_icono_tipo_documento');

// Actividades Realizadas
function crear_tipo_actividad() {
    $labels = array(
        'name' => 'Actividades',
        'singular_name' => 'Actividad',
        'add_new' => 'Añadir nueva',
        'add_new_item' => 'Añadir nueva actividad',
        'edit_item' => 'Editar actividad',
        'new_item' => 'Nueva actividad',
        'all_items' => 'Todas las actividades',
        'view_item' => 'Ver actividad',
        'search_items' => 'Buscar actividades',
        'not_found' => 'No se encontraron actividades',
        'menu_name' => 'Actividades'
    );
    $args = array(
        'labels' => $labels,
        'public' => true,
        'menu_position' => 5,
        'supports' => array('title', 'editor', 'thumbnail'),
        'has_archive' => true
    );
    register_post_type('actividad', $args);
}
add_action('init', 'crear_tipo_actividad');

function guardar_actividades_estudiante() {
    if (isset($_POST['guardar_actividades']) && !empty($_POST['actividades'])) {
        $user_id = get_current_user_id();
        $actividades_completadas = $_POST['actividades'];
        
        // Inicializar el total de horas y la lista de actividades realizadas
        $total_horas = 0;
        $actividades_realizadas = [];

        foreach ($actividades_completadas as $actividad_id) {
            $horas = get_field('horas', $actividad_id);
            $total_horas += (int) $horas;
            $actividades_realizadas[] = $actividad_id; // Agregar cada actividad realizada
        }

        // Actualizar la información del usuario
        update_user_meta($user_id, 'horas_realizadas', $total_horas);
        update_user_meta($user_id, 'actividades_completadas', $actividades_completadas);
        update_user_meta($user_id, 'actividades_realizadas', $actividades_realizadas);
    }
}
add_action('template_redirect', 'guardar_actividades_estudiante');

//Eventos
function mostrar_eventos() {
    ob_start();
    ?>
    <div class="event-management">
        <h2>Gestión de Eventos</h2>

        <!-- Filtros por categoría -->
        <form method="GET" action="">
            <label for="categoria_evento">Filtrar por Categoría:</label>
            <select name="categoria_evento" id="categoria_evento">
                <option value="">Todas las Categorías</option>
                <?php
                $categorias = get_terms('tribe_events_cat');
                foreach ($categorias as $categoria) {
                    $selected = isset($_GET['categoria_evento']) && $_GET['categoria_evento'] === $categoria->slug ? 'selected' : '';
                    echo '<option value="' . esc_attr($categoria->slug) . '" ' . $selected . '>' . esc_html($categoria->name) . '</option>';
                }
                ?>
            </select>
            <button type="submit">Filtrar</button>
        </form>

        <!-- Mensajes de retroalimentación -->
        <?php
        if (isset($_GET['inscripcion_exitosa'])) {
            echo '<p class="success-message">¡Te has inscrito exitosamente en el evento!</p>';
        }

        if (isset($_GET['ya_inscrito'])) {
            echo '<p class="warning-message">Ya estás inscrito en este evento.</p>';
        }

        if (isset($_GET['error']) && $_GET['error'] === 'evento_invalido') {
            echo '<p class="error-message">El evento no es válido.</p>';
        }
        ?>

        <!-- Listado de eventos -->
        <?php
        $categoria_evento = isset($_GET['categoria_evento']) ? sanitize_text_field($_GET['categoria_evento']) : '';
        $args = array(
            'post_type' => 'tribe_events',
            'posts_per_page' => 10,
            'orderby' => 'event_date',
            'order' => 'ASC',
        );

        if (!empty($categoria_evento)) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'tribe_events_cat',
                    'field'    => 'slug',
                    'terms'    => $categoria_evento,
                ),
            );
        }

        $eventos = new WP_Query($args);

        if ($eventos->have_posts()) :
            while ($eventos->have_posts()) : $eventos->the_post();
                $evento_fecha = tribe_get_start_date(get_the_ID(), false, 'd/m/Y H:i');
                $evento_ubicacion = tribe_get_address(get_the_ID());
                ?>
                <div class="evento">
                    <h3><?php the_title(); ?></h3>
                    <p>Fecha: <?php echo esc_html($evento_fecha); ?></p>
                    <p>Ubicación: <?php echo esc_html($evento_ubicacion); ?></p>
                    <a href="<?php the_permalink(); ?>">Ver Más</a>
                    <form method="POST" action="">
                        <input type="hidden" name="evento_id" value="<?php echo get_the_ID(); ?>">
                        <?php wp_nonce_field('inscribirse_evento', 'evento_nonce'); ?>
                        <button type="submit" name="inscribirse">Inscribirse</button>
                    </form>
                </div>
                <?php
            endwhile;
        else :
            echo '<p>No se encontraron eventos disponibles.</p>';
        endif;
        wp_reset_postdata();
        ?>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('gestionar_eventos', 'mostrar_eventos');


//Mostrar eventos inscritos en la barra lateral
function mostrar_eventos_inscritos($user_id) {
    $eventos_inscritos = new WP_Query(array(
        'post_type' => 'tribe_events',
        'meta_query' => array(
            array(
                'key' => 'inscritos',
                'value' => '"' . $user_id . '"',
                'compare' => 'LIKE',
            ),
        ),
    ));

    if ($eventos_inscritos->have_posts()) :
        echo '<div class="event-sidebar"><h3>Mis Eventos</h3><ul>';
        while ($eventos_inscritos->have_posts()) : $eventos_inscritos->the_post();
            echo '<li><a href="' . get_the_permalink() . '">' . get_the_title() . '</a></li>';
        endwhile;
        echo '</ul></div>';
        wp_reset_postdata();
    else :
        echo '<p>No estás inscrito en ningún evento.</p>';
    endif;
}


function manejar_inscripcion_evento() {
    // Verificar que el formulario fue enviado y que el usuario está logueado
    if (isset($_POST['inscribirse']) && is_user_logged_in()) {
        // Validar el nonce de seguridad
        if (!isset($_POST['evento_nonce']) || !wp_verify_nonce($_POST['evento_nonce'], 'inscribirse_evento')) {
            wp_die('Acceso no autorizado.');
        }

        // Obtener el ID del evento desde el formulario
        $evento_id = intval($_POST['evento_id']);
        $user_id = get_current_user_id();

        // Verificar si el ID del evento es válido
        if (get_post_type($evento_id) === 'tribe_events') {
            // Obtener o inicializar la lista de inscritos
            $inscritos = get_post_meta($evento_id, 'inscritos', true);
            $inscritos = is_array($inscritos) ? $inscritos : [];

            // Verificar si el usuario ya está inscrito
            if (!in_array($user_id, $inscritos)) {
                // Agregar al usuario y actualizar el metadato
                $inscritos[] = $user_id;
                update_post_meta($evento_id, 'inscritos', $inscritos);

                // Redirigir con mensaje de éxito
                wp_redirect(add_query_arg('inscripcion_exitosa', 'true', get_permalink($evento_id)));
                exit;
            } else {
                // Redirigir con mensaje de inscripción duplicada
                wp_redirect(add_query_arg('ya_inscrito', 'true', get_permalink($evento_id)));
                exit;
            }
        } else {
            // Redirigir con mensaje de error si no es un evento válido
            wp_redirect(add_query_arg('error', 'evento_invalido', get_permalink()));
            exit;
        }
    }
}
add_action('template_redirect', 'manejar_inscripcion_evento');

function usar_plantilla_personalizada_para_eventos($template) {
    if (tribe_is_event() && is_singular('tribe_events')) {
        $template_personalizado = locate_template('tribe/events/single-event.php');
        if ($template_personalizado) {
            return $template_personalizado;
        }
    }
    return $template;
}
add_filter('template_include', 'usar_plantilla_personalizada_para_eventos');


function mostrar_eventos_inscritos_usuario() {
    $user_id = get_current_user_id();

    if (!$user_id) {
        echo '<p>Debes iniciar sesión para ver tus eventos inscritos.</p>';
        return;
    }

    // Consulta para obtener eventos donde el usuario esté inscrito
    $args = array(
        'post_type' => 'tribe_events',
        'meta_query' => array(
            array(
                'key'     => 'inscritos',
                'value'   => sprintf('i:%d;', $user_id), // Buscar ID del usuario serializado.
                'compare' => 'LIKE',
            ),
        ),
    );

    $eventos_inscritos = new WP_Query($args);

    // Mostrar los eventos inscritos con diseño mejorado
    if ($eventos_inscritos->have_posts()) {
        echo '<div class="eventos-inscritos-container">';
        echo '<h3>Mis Eventos Inscritos</h3>';
        echo '<div class="eventos-inscritos-grid">';

        while ($eventos_inscritos->have_posts()) {
            $eventos_inscritos->the_post();
            $fecha = tribe_get_start_date(get_the_ID(), false, 'F j, Y g:i a'); // Obtener la fecha del evento.
            $ubicacion = tribe_get_address(get_the_ID()); // Obtener la ubicación del evento.
            $imagen = get_the_post_thumbnail(get_the_ID(), 'medium', ['class' => 'evento-thumbnail']); // Miniatura del evento.

            echo '<div class="evento-inscrito-item">';
            echo $imagen; // Mostrar miniatura.
            echo '<div class="evento-inscrito-info">';
            echo '<h4><a href="' . get_permalink() . '">' . get_the_title() . '</a></h4>';
            echo '<p class="evento-fecha">Fecha: ' . esc_html($fecha) . '</p>';
            if ($ubicacion) {
                echo '<p class="evento-ubicacion">Ubicación: ' . esc_html($ubicacion) . '</p>';
            }
            echo '</div>'; // Cierre de evento-inscrito-info.
            echo '</div>'; // Cierre de evento-inscrito-item.
        }

        echo '</div>'; // Cierre de eventos-inscritos-grid.
        echo '</div>'; // Cierre de eventos-inscritos-container.
    } else {
        echo '<p>No estás inscrito en ningún evento.</p>';
    }

    wp_reset_postdata();
}

//Eventos página principal
function mostrar_eventos_principales($cantidad = 5) {
    // Obtener los próximos eventos
    $args = array(
        'post_type'      => 'tribe_events',
        'posts_per_page' => $cantidad,
        'meta_key'       => '_EventStartDate',
        'orderby'        => 'meta_value',
        'order'          => 'ASC',
        'meta_query'     => array(
            array(
                'key'     => '_EventStartDate',
                'value'   => current_time('Y-m-d H:i:s'),
                'compare' => '>=',
                'type'    => 'DATETIME',
            ),
        ),
    );

    $eventos = new WP_Query($args);

    // Mostrar los eventos
    if ($eventos->have_posts()) {
        echo '<div class="eventos-principales">';
        echo '<h2>Próximos Eventos</h2>';
        echo '<div class="eventos-grid">';
        while ($eventos->have_posts()) {
            $eventos->the_post();
            $fecha = tribe_get_start_date(get_the_ID(), false, 'F j, Y g:i a'); // Fecha del evento.
            $ubicacion = tribe_get_address(get_the_ID()); // Ubicación del evento.
            $imagen = get_the_post_thumbnail(get_the_ID(), 'evento-mini', ['class' => 'evento-thumbnail']);


            // $imagen = get_the_post_thumbnail(get_the_ID(), 'medium', ['class' => 'evento-thumbnail']); // Imagen destacada.

            echo '<div class="evento-item">';
            echo $imagen; // Miniatura del evento.
            echo '<div class="evento-info">';
            echo '<h3><a href="' . get_permalink() . '">' . get_the_title() . '</a></h3>';
            echo '<p class="evento-fecha">Fecha: ' . esc_html($fecha) . '</p>';
            if ($ubicacion) {
                echo '<p class="evento-ubicacion">Ubicación: ' . esc_html($ubicacion) . '</p>';
            }
            echo '</div>'; // Cierre de evento-info.
            echo '</div>'; // Cierre de evento-item.
        }
        echo '</div>'; // Cierre de eventos-grid.
        echo '</div>'; // Cierre de eventos-principales.
    } else {
        echo '<p>No hay eventos próximos disponibles.</p>';
    }

    wp_reset_postdata();
}

add_action('after_setup_theme', function() {
    add_image_size('evento-mini', 150, 150, true); // 150x150 píxeles, recorte forzado.
});
//Agregar efectos scroll
function agregar_efectos_scroll() {
    wp_enqueue_script('scroll-effects', get_template_directory_uri() . '/js/scroll-effects.js', array(), '1.0', true);
}
add_action('wp_enqueue_scripts', 'agregar_efectos_scroll');

function cargar_aos() {
    wp_enqueue_style('aos-css', 'https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css');
    wp_enqueue_script('aos-js', 'https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js', array(), null, true);
    wp_add_inline_script('aos-js', 'AOS.init();');
}
add_action('wp_enqueue_scripts', 'cargar_aos');

