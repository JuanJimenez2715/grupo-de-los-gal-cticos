<?php
get_header();
?>

<div class="event-container">
    
    <!-- Contenedor principal del evento -->
    <div class="event-content">
        <?php while (have_posts()) : the_post(); ?>
            <h1 class="event-title"><?php the_title(); ?></h1>
            <p class="event-date"><strong>Fechaat:</strong> <?php echo tribe_get_start_date(get_the_ID(), false, 'd/m/Y H:i'); ?></p>
            <p class="event-location"><strong>Ubicación:</strong> <?php echo tribe_get_address(get_the_ID()); ?></p>
            <div class="event-description">
                <?php the_content(); ?>
            </div>

            <!-- Mensajes de retroalimentación -->
            <?php
            if (isset($_GET['inscripcion_exitosa'])) {
                echo '<p class="success-message">¡Te has inscrito exitosamente en este evento!</p>';
            }

            if (isset($_GET['ya_inscrito'])) {
                echo '<p class="warning-message">Ya estás inscrito en este evento.</p>';
            }

            if (isset($_GET['error']) && $_GET['error'] === 'evento_invalido') {
                echo '<p class="error-message">Hubo un problema con la inscripción.</p>';
            }
            ?>

            <!-- Formulario de inscripción -->
            <?php if (is_user_logged_in()) : ?>
                <form method="POST" action="" class="event-subscription-form">
                    <input type="hidden" name="evento_id" value="<?php echo get_the_ID(); ?>">
                    <?php wp_nonce_field('inscribirse_evento', 'evento_nonce'); ?>
                    <button type="submit" name="inscribirse" class="event-subscription-button">
                    Inscribirse
                    </button>
                </form>
            <?php else : ?>
                <p class="login-prompt">
                    Por favor <a href="<?php echo wp_login_url(get_permalink()); ?>">inicia sesión</a> para inscribirte en este evento.
                </p>
            <?php endif; ?>
        <?php endwhile; ?>
    </div>
</div>

<?php
get_footer();
