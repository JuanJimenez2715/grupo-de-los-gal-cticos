<?php
/*
Template Name: Servicios Universitarios
*/

get_header(); ?>

<div class="container">
    <h1>Servicios Universitarios</h1>
    <div class="services-posts">
        <?php
        // Argumentos para la consulta de entradas
        $args = array(
            'category_name' => 'servicios-universitarios', // Cambia esto por el slug de tu categoría
            'post_type' => 'post',
            'posts_per_page' => 10 // Cambia el número de entradas a mostrar si lo deseas
        );

        // Consulta personalizada de entradas
        $servicios_query = new WP_Query($args);

        if ($servicios_query->have_posts()) :
            while ($servicios_query->have_posts()) : $servicios_query->the_post(); ?>
                <article class="service-post">
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <?php if (has_post_thumbnail()) : ?>
                        <div class="service-thumbnail">
                            <?php the_post_thumbnail('medium'); ?>
                        </div>
                    <?php endif; ?>
                    <div class="service-excerpt">
                        <?php the_excerpt(); ?>
                    </div>
                </article>
            <?php endwhile;
            wp_reset_postdata();
        else : ?>
            <p>No se han encontrado servicios universitarios.</p>
        <?php endif; ?>
    </div>
</div>

<?php get_footer(); ?>
