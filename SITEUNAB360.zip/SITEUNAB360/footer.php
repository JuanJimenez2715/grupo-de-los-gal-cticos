</div> <!-- Cierre de .site-content -->

<footer>
    <div class="footer-container">
        <!-- Primera columna: Logo y texto -->
        <div class="footer-column">
           <!-- <img src="URL_DE_LA_IMAGEN" alt="Logo de la Universidad" class="footer-logo">-->
           <a href="<?php echo esc_url(home_url('/')); ?>">
           <img src="<?php echo get_template_directory_uri(); ?>/images/Max4.png" alt="<?php bloginfo('Mascota UNAB'); ?>">
           </a>
           <p class="footer-description">Tu Guía Estudiantil en Línea</p>
        </div>
        
        <!-- Segunda columna: Derechos reservados y menú -->
        <div class="footer-column">
            <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. Derechos reservados.</p>
            <nav class="footer-menu">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'footer',
                    'menu_class' => 'nav-menu'
                ));
                ?>
            </nav>
        </div>
        
        <!-- Tercera columna: Información de contacto y redes sociales -->
        <div class="footer-column">
            <p>Contacto: <a href="mailto:contactenos@unab.edu.co">contactenos@unab.edu.co</a></p>
            <p>Teléfono: 018000127395</p>
            <div class="social-icons">
            <a href="https://facebook.com/unab" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a href="https://twitter.com/unab" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://instagram.com/unab" target="_blank"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
    </div>
</footer>

<?php wp_footer(); ?>

</body>
</html>
