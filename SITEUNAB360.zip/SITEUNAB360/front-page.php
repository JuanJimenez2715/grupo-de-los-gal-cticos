<?php
/* Template Name: Página Principal */
get_header();
?>

<div class="container">

    <!-- Noticias Principales -->
    <section class="main-content scroll-animation" data-aos="fade-up">
        <h2 class="scroll-animation" data-aos="fade-up">Noticias Principales</h2>
        <?php
        $noticias_query = new WP_Query(array(
            'category_name' => 'noticias', // Usa el slug de la categoría de noticias
            'posts_per_page' => 5, // Número de noticias a mostrar
        ));
        if ($noticias_query->have_posts()) :
            while ($noticias_query->have_posts()) : $noticias_query->the_post(); ?>
                <article class="noticia scroll-animation" data-aos="fade-up" data-aos-delay="100">
                    <?php if (has_post_thumbnail()) : ?>
                        <a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('medium'); ?></a>
                    <?php endif; ?>
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p><?php the_excerpt(); ?></p>
                </article>
            <?php endwhile;
            wp_reset_postdata();
        else : ?>
            <p>No hay noticias disponibles.</p>
        <?php endif; ?>
    </section>

    <!-- Blog (a la derecha) -->
    <aside class="sidebar scroll-animation" data-aos="fade-left">
        <h2>Blog</h2>
        <?php
        $blog_query = new WP_Query(array(
            'category_name' => 'blog', // Usa el slug de la categoría de blog
            'posts_per_page' => 5, // Número de entradas de blog a mostrar
        ));
        if ($blog_query->have_posts()) :
            while ($blog_query->have_posts()) : $blog_query->the_post(); ?>
                <article class="blog-post scroll-animation" data-aos="fade-left" data-aos-delay="100">
                    <h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <p><?php the_excerpt(); ?></p>
                </article>
            <?php endwhile;
            wp_reset_postdata();
        else : ?>
            <p>No hay entradas de blog disponibles.</p>
        <?php endif; ?>
    </aside>

    <!-- Eventos (parte inferior) -->
    <section class="events scroll-animation" data-aos="zoom-in">
        <?php mostrar_eventos_principales(6); // Mostrar los próximos 6 eventos. ?>  
    </section>
</div>

<?php get_footer(); ?>
