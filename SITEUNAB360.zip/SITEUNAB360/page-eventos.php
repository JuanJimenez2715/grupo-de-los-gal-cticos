<?php
/*
Template Name: Gestión de Eventos
*/
get_header();
?>

<div class="content-area" style="padding: 20px;">
    <main class="site-main" style="display: flex; flex-wrap: wrap; gap: 20px; align-items: flex-start;">

        <!-- Contenido principal: Gestión de eventos -->
        <section class="event-main-content" style="flex: 3; border-right: 2px solid #ddd; padding-right: 20px; margin-bottom: 20px;">
            <h2 style="margin-bottom: 20px; text-align: center; font-size: 24px; color: #333;">Gestión de Eventos</h2>
            <?php echo do_shortcode('[gestionar_eventos]'); ?>
        </section>

        <!-- Barra lateral: Eventos inscritos -->
        <aside class="event-sidebar" style="flex: 1; padding-left: 20px; background-color: #f9f9f9; border-radius: 8px; border: 1px solid #ddd;">
        <?php mostrar_eventos_inscritos_usuario(); ?>
        </aside>
    </main>
</div>

<?php
get_footer();
?>

