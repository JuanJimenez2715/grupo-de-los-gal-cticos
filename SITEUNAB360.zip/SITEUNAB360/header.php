<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="<?php echo get_stylesheet_uri(); ?>">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<!-- Barra Superior con Iniciar Sesión -->
<div class="top-bar">
    <div class="top-bar-content">
        <!-- Botón de Iniciar Sesión/Cerrar Sesión -->
        <div class="login-button">
            <?php if (!is_user_logged_in()) : ?>
                <a href="<?php echo wp_login_url(); ?>">Iniciar Sesión</a>
            <?php else : ?>
                <a href="<?php echo wp_logout_url(); ?>">Cerrar Sesión</a>
            <?php endif; ?>
        </div>

        <?php
        // Cargar el menú superior si está asignado en el panel de administración
        if (has_nav_menu('top-menu')) {
            wp_nav_menu(array(
                'theme_location' => 'top-menu',
                'container' => 'nav',
                'container_class' => 'top-menu-nav',
                'menu_class' => 'top-menu'
            ));
        }
        ?>
    </div>
</div>

<header>
    <div class="header-container">
        <div class="logo">
            <a href="<?php echo esc_url(home_url('/')); ?>">
                <img src="<?php echo get_template_directory_uri(); ?>/images/Logo_UNAB_150.jpg" alt="<?php bloginfo('name'); ?>">
            </a>
        </div>

        <!-- Menú móvil: Botón hamburguesa -->
        <button id="mobile-menu-toggle" aria-label="Toggle Menu">
            ☰
        </button>

        <div class="main-menu">
            <?php
            wp_nav_menu(array(
                'theme_location' => 'main-menu',
                'container' => 'nav',
                'container_class' => 'main-menu-nav',
                'menu_class' => 'nav-menu'
            ));
            ?>
        </div>
    </div>
</header>

<div class="site-content">
