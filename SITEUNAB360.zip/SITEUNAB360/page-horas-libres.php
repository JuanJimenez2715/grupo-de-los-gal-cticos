<?php
/* Template Name: Página Horas Libres */
get_header();
$current_user = wp_get_current_user();
// Imprimir información del usuario actual
//echo '<pre>';
//echo 'Información del usuario actual:' . PHP_EOL;
//print_r($current_user);
//echo '</pre>';
// Validar si el usuario tiene acceso
if (!in_array('estudiante', (array) $current_user->roles)) {
    echo '<p>No tienes permiso para acceder a esta página.</p>';
    get_footer();
    exit;
}

$user_id = $current_user->ID;

// Obtener metadatos del usuario
$total_horas_requeridas = (int) get_user_meta($user_id, 'horas_totales_asignadas', true);
if (!$total_horas_requeridas) {
    $total_horas_requeridas = 100; // Valor por defecto
}

$horas_realizadas = (int) get_user_meta($user_id, 'horas_realizadas', true);
$horas_faltantes = max(0, $total_horas_requeridas - $horas_realizadas);

$actividades_realizadas = get_user_meta($user_id, 'actividades_realizadas', true);
if (!$actividades_realizadas) {
    $actividades_realizadas = array();
}
?>
<div class="container_HL">
    <h1 class="page-title_HL">Horas Libres</h1>
    
    <div class="layout_HL">
        <!-- Listado de actividades -->
        <div class="actividades-listado">
            <form method="post">
                <?php
                $actividades = new WP_Query(array(
                    'post_type' => 'actividad',
                    'post_status' => 'publish',
                    'posts_per_page' => -1,
                ));

                if ($actividades->have_posts()) :
                    while ($actividades->have_posts()) : $actividades->the_post();
                        $horas = get_field('horas'); 
                        $foto = get_field('foto');
                        $actividades_completadas = get_user_meta($user_id, 'actividades_completadas', true);
                        if (!is_array($actividades_completadas)) {
                        $actividades_completadas = []; // Inicializa como array vacío si no es un array.
                        }

                        $checked = in_array(get_the_ID(), $actividades_completadas) ? 'checked' : '';

                        //$checked = in_array(get_the_ID(), get_user_meta($user_id, 'actividades_completadas', true)) ? 'checked' : '';
                        ?>
                        <div class="actividad-item">
                            <?php if ($foto) : ?>
                                <img src="<?php echo esc_url($foto['url']); ?>" alt="<?php echo esc_attr($foto['alt']); ?>" />
                            <?php endif; ?>
                            <h2><?php the_title(); ?></h2>
                            <p><?php the_field('descripcion'); ?></p>
                            <p>Horas: <?php echo esc_html($horas); ?></p>
                            <label>
                                <input type="checkbox" name="actividades[]" value="<?php the_ID(); ?>" <?php echo $checked; ?>>
                                Marcar como realizada
                            </label>
                        </div>
                    <?php endwhile;
                    wp_reset_postdata();
                else :
                    echo '<p>No hay actividades disponibles.</p>';
                endif;
                ?>
                <button type="submit" name="guardar_actividades">Guardar Actividades Realizadas</button>
            </form>
        </div>

        <!-- Resumen -->
        <div class="sidebar">
            <h3>Resumen</h3>
            <p><strong>Usuario:</strong> <?php echo esc_html($current_user->display_name); ?></p>
            <p>Horas realizadas: <?php echo esc_html($horas_realizadas); ?></p>
            <p><strong>Horas faltantes:</strong> <?php echo esc_html($horas_faltantes); ?></p>
            <p>Actividades:</p>
            <ul>
                <?php
                if (!empty($actividades_realizadas)) {
                    foreach ($actividades_realizadas as $actividad_id) {
                        echo '<li>' . get_the_title($actividad_id) . '</li>';
                    }
                } else {
                    echo '<li>No hay actividades completadas.</li>';
                }
                ?>
            </ul>
        </div>
    </div>
</div>
<?php get_footer(); ?>
