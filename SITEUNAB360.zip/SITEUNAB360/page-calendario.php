<?php get_header(); ?>
<!-- Encabezado Principal -->
<section class="calendario-intro">
    <div class="container">
        <h1>Calendario de Eventos Universitarios</h1>
        <p>Encuentra aquí todos los eventos y actividades de nuestra universidad. Selecciona la vista que prefieras para organizar mejor tu tiempo.</p>
    </div>
</section>

<!-- Navegación de Vistas de Calendario -->
<section class="calendario-vistas">
    <div class="container">
        <div class="vista-opciones">
            <a href="#vista-mes" class="btn-vista">Vista Mensual</a>
            <a href="#vista-semana" class="btn-vista">Vista Semanal</a>
            <a href="#vista-lista" class="btn-vista">Vista de Lista</a>
            <a href="#vista-dia" class="btn-vista">Vista Diaria</a>
        </div>
    </div>
</section>

<!-- Vista Mensual -->
<section id="vista-mes" class="calendario-vista">
    <div class="container">
        <h2>Vista Mensual</h2>
        <p>Visualiza los eventos del mes en curso.</p>
        [tribe_events view="month"]
    </div>
</section>

<!-- Vista Semanal -->
<section id="vista-semana" class="calendario-vista">
    <div class="container">
        <h2>Vista Semanal</h2>
        <p>Organiza los eventos de la semana.</p>
        [tribe_events view="week"]
    </div>
</section>

<!-- Vista de Lista -->
<section id="vista-lista" class="calendario-vista">
    <div class="container">
        <h2>Vista de Lista</h2>
        <p>Consulta todos los eventos en un formato de lista.</p>
        [tribe_events view="list"]
    </div>
</section>

<!-- Vista Diaria -->
<section id="vista-dia" class="calendario-vista">
    <div class="container">
        <h2>Vista Diaria</h2>
        <p>Explora los eventos de un día específico.</p>
        [tribe_events view="day"]
    </div>
</section>

<!-- Estilos CSS -->
<style>
    /* Contenedor principal */
    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 1rem;
    }

    /* Estilos de sección */
    .calendario-intro, .calendario-vista {
        margin: 2rem 0;
        padding: 2rem 1rem;
        background-color: #f4f4f9;
        border-radius: 8px;
    }

    .calendario-intro {
        background-color: #ff9900f1;
        color: white;
        text-align: center;
    }

    .calendario-vista h2 {
        color: #2b2f3e;
        text-align: left;
    }

    .calendario-vista p {
        color: #555;
    }

    /* Botones de vista */
    .vista-opciones {
        display: flex;
        justify-content: center;
        gap: 1rem;
    }

    .btn-vista {
        display: inline-block;
        padding: 0.75rem 1.5rem;
        background-color: #007bff;
        color: #ffffff;
        font-weight: bold;
        border-radius: 5px;
        text-decoration: none;
        transition: background-color 0.3s;
    }

    .btn-vista:hover {
        background-color: #0056b3;
    }
</style>
<?php get_footer(); ?>