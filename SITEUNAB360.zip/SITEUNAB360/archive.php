<?php get_header(); ?>

<div class="container">
    <h1><?php post_type_archive_title(); ?></h1>

    <?php if (have_posts()) : ?>
        <div class="post-list">
            <?php while (have_posts()) : the_post(); ?>
                <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                    <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                    <div class="post-meta">
                        <span>Publicado el: <?php the_date(); ?></span>
                    </div>
                    <div class="post-excerpt">
                        <?php the_excerpt(); ?>
                    </div>
                </article>
            <?php endwhile; ?>
        </div>

        <div class="pagination">
            <?php
            previous_posts_link('← Publicaciones Anteriores');
            next_posts_link('Publicaciones Siguientes →');
            ?>
        </div>
    <?php else : ?>
        <p>No se encontraron publicaciones.</p>
    <?php endif; ?>
</div>

<?php get_footer(); ?>
